export const rem = (value) => `${value / 10}rem`;
