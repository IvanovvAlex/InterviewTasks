import { StyledSectionContainer } from "./elements";

export const SectionContainer = ({ ...props }) => {
  return <StyledSectionContainer {...props} />;
};
