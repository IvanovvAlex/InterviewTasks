import { StyledSectionBigHeading } from "./elements";

export const SectionBigHeading = ({ ...props }) => {
  return <StyledSectionBigHeading {...props} />;
};
