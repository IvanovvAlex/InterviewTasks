import { StyledSectionInnerHeading } from "./elements";

export const SectionInnerHeading = ({ ...props }) => {
  return <StyledSectionInnerHeading {...props} />;
};
