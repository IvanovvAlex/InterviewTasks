import { forwardRef } from "react";
import { StyledSectionHeading } from "./elements";

export const SectionHeading = ({ ...props }) => {
  return <StyledSectionHeading {...props} />;
};
