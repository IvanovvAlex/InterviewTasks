import { StyledSectionTinyHeading } from "./elements";

export const SectionTinyHeading = ({ ...props }) => {
  return <StyledSectionTinyHeading {...props} />;
};
