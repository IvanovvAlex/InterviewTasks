export * from "./SectionBigHeading";
export * from "./SectionHeading";
export * from "./SectionSubheading";
export * from "./SectionInnerHeading";
export * from "./SectionParagraph";
export * from "./SectionTinyHeading";
