import { StyledSectionParagraph } from "./elements";

export const SectionParagraph = ({ ...props }) => {
  return <StyledSectionParagraph {...props} />;
};
