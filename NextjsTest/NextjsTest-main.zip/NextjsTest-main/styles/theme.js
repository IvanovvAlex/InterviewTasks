export const theme = {
  black: "#000000",
  white: "#FFFFFF",
  main: "#006EFD",
  red: "#E74C5B",
  black1B: "#1B1B1B",
  grayF0: "#F0F0F0",
  gray8D: "#8D8F92",
  grayE2: "#E2E2E2",
  grayEA: "#EAEAEA",
  gray70: "#707070",
  gray37: "#372B25",
  hover: {
    main: "#E2E2E2",
  },
  typography: {
    bigHeading: {},
  },
};
