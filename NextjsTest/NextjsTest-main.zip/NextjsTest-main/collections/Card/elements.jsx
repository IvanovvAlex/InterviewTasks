// Styled elements for the Card go here
